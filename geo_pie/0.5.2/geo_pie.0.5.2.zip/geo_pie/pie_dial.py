# -*- coding: utf-8 -*-

import os

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QDialog
from qgis.PyQt.QtCore import QVariant, Qt

from qgis.core import (
                       QgsProject,
                       Qgis,
                       QgsVectorLayer,
                       QgsField,
                       QgsGeometry,
                       QgsFeature,
                       QgsFieldProxyModel,
                       QgsMapLayerProxyModel,
                      )

#from qgis.gui import  (QgsProjectionSelectionWidget,
#                      QgsCoordinateReferenceSystemProxyModel)

from .utilib import EncDec

#-----------------------------------------------------------------------------
# Форма скрипта создающего таблицу расстояний между скважинами (точками )
# и записывающего результат в *.csv или *.htm файл. Опционально можно создать
# граф (линии ) между точками.
#-----------------------------------------------------------------------------
FORM_CLASS_1, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/wells_matrix.ui'))


class formWellsMatrix(QtWidgets.QDialog, FORM_CLASS_1):

    msgBox = QtWidgets.QMessageBox()

    def __init__(self, parent=None):
        super(formWellsMatrix, self).__init__(parent)
        self.setupUi(self)

        # Реакция на выбор слоя в mLayer
        self.mLayer.activated.connect(self.activ_mLayer)
        self.mLayer.currentIndexChanged.connect(self.activ_mLayer)
        self.mFile.setFilter('Таблица с разделителем CSV (*.csv);;\
                              Web - страница  (*.htm)')

        # Инициализация выбора кодировки
        self.encode_combo.addItem('- не выбрана -')
        self.encode_combo.insertSeparator(1)
        self.enc = EncDec()
        self.encode_combo.addItems(self.enc.item)
        self.encode_combo.currentIndexChanged.connect(self.set_encode)

        self.decode_combo.addItems(self.enc.item)
        self.decode_combo.currentIndexChanged.connect(self.set_decode)

        self.checkBox_matrix.setChecked(False)

    # Выбор кодировки
    def set_encode(self):
        self.enc.set_enc(self.encode_combo.currentIndex()-2)

    def set_decode (self):
        self.enc.set_dec(self.decode_combo.currentIndex())

    # Описание реакции mLayer на активацию и выбор
    def activ_mLayer(self):
        self.mLayer.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.mField.setFilters(QgsFieldProxyModel.String|QgsFieldProxyModel.Int)
        self.mField.setLayer(self.mLayer.currentLayer())

        self.checkBox_Features.setChecked(False)
        # Получение выбранного слоя
        # Перед тем как активировать галочку с отмеченными объектами
        # необходимо убедиться в наличии слоя
        wells_vLayer = False
        wells_vLayer = self.mLayer.currentLayer()
        # Проверка на наличие выборки. Если есть выбранные объекты,
        # сделать доступным галочку
        if wells_vLayer and wells_vLayer.selectedFeatures() :
            self.checkBox_Features.setEnabled(True)
        else :
            self.checkBox_Features.setEnabled(False)

    # Перегрузка метода диалогового окна accept для
    # проверки заполненности всех полей формы
    def accept (self) :
        filename = self.mFile.lineEdit().text()
        dir_name = os.path.dirname(filename)
        if os.path.isdir(dir_name) and self.mField.currentField():
            self.done(QDialog.DialogCode.Accepted)
        else :
            self.msgBox.warning(self,"Матрица скважин",
                                "Не все поля заполнены.")

    # Подготовка и запуск формы диалога
    def run (self):
        self.activ_mLayer()
        self.exec()
        return self.result()

    def featwells (self):
        wells_vLayer = self.mLayer.currentLayer()
        if self.checkBox_Features.isChecked() :
            features = wells_vLayer.selectedFeatures()
        else :
            features=[feature for feature in wells_vLayer.getFeatures()]

        return features

    def namefield (self):
        return self.mField.currentField()

    def filename (self):
        return self.mFile.lineEdit().text()

    def is_graph (self):
        return self.checkBox_matrix.isChecked()

    def layer (self):
        return self.mLayer.currentLayer()
#-----------------------------------------------------------------------------
#      formWellMatrix()
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Форма скрипта создающего точки из csv таблицы
# formCSVshape
#-----------------------------------------------------------------------------
FORM_CLASS_2, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/csv_to_shape.ui'))


class formCSVshape(QtWidgets.QDialog, FORM_CLASS_2):
    msgBox = QtWidgets.QMessageBox()
    split_char = ';'

    def __init__(self, parent=None):
        super(formCSVshape, self).__init__(parent)
        self.setupUi(self)

        self.csv_file_widget.setFilter('Таблица с разделителем CSV (*.csv);;\
                                       Любой файл (*)')
        self.csv_file_widget.fileChanged.connect(self.change_head)
        # Инициализация выбора кодировки
        self.encode_comboBox.addItem('- не выбрана -')
        self.encode_comboBox.insertSeparator(1)
        self.enc = EncDec()
        self.encode_comboBox.addItems(self.enc.item)
        self.encode_comboBox.setCurrentIndex(0)
        self.encode_comboBox.currentIndexChanged.connect(self.set_encode)

        self.field_check.clicked.connect(self.change_head)

    # Выбор кодировки
    def set_encode(self):
        self.enc.set_enc(self.encode_comboBox.currentIndex()-2)
        self.enc.set_dec(self.encode_comboBox.currentIndex()-2)
        if self.csv_file_widget.lineEdit().text():
            self.change_head()

    # Подготовка и запуск формы диалога
    def run(self):
        self.exec()
        return self.result()

    # Перегрузка ok
    def accept(self):
        if not self.csv_file_widget.lineEdit().text():
            self.msgBox.warning(self,
                                "Ошибка выполнения",
                                "Файла не существует"
                                )
        elif (self.longitude_comboBox.currentIndex()<0 or
              self.latitude_comboBox.currentIndex()<0):
            self.msgBox.warning(self,
                                "Ошибка выполнения",
                                "Не все поля выбраны."
                                )
        else:
            if self.decode_check.isChecked():
                self.enc.set_dec(0)
            self.done(QDialog.DialogCode.Accepted)

    # Выбор файла
    def csv_open(self):
        # Чтение файла
        csvpath = self.csv_file_widget.lineEdit().text()
        try:
            with open (csvpath, 'r',
                       encoding=self.enc.enc,
                       errors=self.enc.err) as csvfile:
                line = csvfile.readline().rstrip('\n')
            csvfile.close()
            return line
        except FileNotFoundError:
            self.msgBox.warning(self,
                                "Ошибка при открытии файла",
                                "Файл не найден."
                                )
            return False
        except UnicodeError:
            self.msgBox.warning(self,
                                "Ошибка при открытии файла",
                                "Смените кодировку"
                                )
            return False
        except Exception as e:
            self.msgBox.warning(self, "Ошибка при открытии файла", e)
            return False

    # Строка заголовка
    def change_head(self):
        self.latitude_comboBox.clear()
        self.longitude_comboBox.clear()
        head = self.csv_open()
        if head:
            head = head.split(self.split_char)
            if not self.field_check.isChecked():
                head = [f'Поле-{i+1} | {cl}' for i, cl in enumerate(head)]
            self.latitude_comboBox.addItems(head)
            self.longitude_comboBox.addItems(head)

    # Возвращает наличие заголовков полей и полное имя файла
    def csvpath (self):
        if self.field_check.isChecked():
            return True, self.csv_file_widget.lineEdit().text()
        else:
            return False, self.csv_file_widget.lineEdit().text()

    def xyFields (self):
        return  (self.longitude_comboBox.currentIndex(),
                self.latitude_comboBox.currentIndex())
#-----------------------------------------------------------------------------
#   formCSVshape
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Форма ввода данных для построения изогнутых скважин.
# В будущем должна разрастись до полноценного разреза
#-----------------------------------------------------------------------------
FORM_CLASS_3, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/curve_wells.ui'))

class formCurveWells(QtWidgets.QDialog, FORM_CLASS_3):
    msgBox = QtWidgets.QMessageBox()

    def __init__(self, parent=None):
        super(formCurveWells, self).__init__(parent)
        self.setupUi(self)

        #self.setFixedSize(330,350)

        # Настройка mLayer (скважины)
        self.mLayer.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.mLayer.activated.connect(self.activ_mLayer)
        self.mLayer.currentIndexChanged.connect(self.activ_mLayer)

        # Настройка mLayer_cut (разрез)
        self.mLayer_cut.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.mLayer_cut.activated.connect(self.activ_mLayer_cut)
        self.mLayer_cut.currentIndexChanged.connect(self.activ_mLayer_cut)

        # Настройка mLayer_srtm
        self.mLayer_srtm.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.mLayer_srtm.setAllowEmptyLayer(True)
        self.mLayer_srtm.setCurrentIndex(0)

        # Настройка поелй с изолиниями mLayer_izln
        self.mLayer_izln.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.mLayer_izln.activated.connect(self.activ_mLayer_izln)
        self.mLayer_izln.currentIndexChanged.connect(self.activ_mLayer_izln)

        # Настройка списка слоев пересечения
        self.data_lnplg = []
        self.mLayer_lnplg.setFilters(
                                     QgsMapLayerProxyModel.PolygonLayer |
                                     QgsMapLayerProxyModel.LineLayer
                                    )
        self.mLayer_lnplg.currentIndexChanged.connect(self.activ_mLayer_lnplg)
        self.pButton_add.clicked.connect(self.add_click)
        self.pButton_remove.clicked.connect(self.remove_click)

        # Настройка типов полей атрибутов
        self.mField_cutname.setFilters(QgsFieldProxyModel.String)
        self.mField_cutname.setAllowEmptyFieldName(True)
        self.mField_well.setFilters(QgsFieldProxyModel.String)
        self.mField_file.setFilters(QgsFieldProxyModel.String)
        self.mField_alt.setFilters(QgsFieldProxyModel.Double)
        self.mField_gtr.setFilters(QgsFieldProxyModel.String)
        self.mField_gtr.setAllowEmptyFieldName(True)

        self.mField_elev.setFilters(
                                    QgsFieldProxyModel.Int |
                                    QgsFieldProxyModel.Double |
                                    QgsFieldProxyModel.LongLong
                                   )
        self.mField_lnplg.setFilters(
                                     QgsFieldProxyModel.String |
                                     QgsFieldProxyModel.Int |
                                     QgsFieldProxyModel.LongLong
                                    )
        # Настройка масштабов
        self.map_mScale.setScale(100000)
        self.cut_mScale.setScale(25000)

    # Действия на активацию и выбор слоя с линиями разреза
    def activ_mLayer_cut (self):
        self.mField_cutname.setLayer(self.mLayer_cut.currentLayer())
        layer = self.mLayer_cut.currentLayer()
        if layer and layer.selectedFeatures() :
            self.chBox_cutfeats.setEnabled(True)
        else :
            self.chBox_cutfeats.setEnabled(False)

    # Действия на активацию и выбор слоя скважин в mLayer
    def activ_mLayer (self):
        # Инициализация полей атрибутов
        self.mField_well.setLayer(self.mLayer.currentLayer())
        self.mField_file.setLayer(self.mLayer.currentLayer())
        self.mField_alt.setLayer(self.mLayer.currentLayer())
        self.mField_gtr.setLayer(self.mLayer.currentLayer())

    # Действия на активацию и выбор слоя изолиний
    def activ_mLayer_izln (self):
        self.mField_elev.setLayer(self.mLayer_izln.currentLayer())

    # Действия на активацию и выбор слоев пересечения
    def activ_mLayer_lnplg (self):
         self.mField_lnplg.setLayer(self.mLayer_lnplg.currentLayer())

    # Действия на нажатие клавиши добавить в список
    def add_click (self):
        layer = self.mLayer_lnplg.currentLayer()
        field = self.mField_lnplg.currentField()
        self.list_lnplg.addItem(f'{layer.name()}\t{field}')
        self.data_lnplg.append((layer, field))

   # Действия на нажатие клавиши удалить из списка
    def remove_click (self):
        index = self.list_lnplg.currentRow()
        if index > -1:
            self.list_lnplg.takeItem(index)
            self.data_lnplg.pop(index)

    # Подготовка и запуск формы диалога
    def run(self):
        self.activ_mLayer_cut()
        self.activ_mLayer()
        self.activ_mLayer_izln()
        self.activ_mLayer_lnplg()
        self.exec()
        return self.result()

    # Перегрузка метода диалогового окна accept для
    # проверки заполненности всех полей формы
    def accept (self) :
        # Проверка пути к файлу и выбранного поля
        if (
            self.mField_well.currentField() and
            self.mField_alt.currentField() and
            self.mField_file.currentField()
           ):
            self.done(QDialog.DialogCode.Accepted)
        else:
            self.msgBox.warning(self,"Матрица скважин",
                                "Не все поля заполнены.")
    def get_layerwells (self):
        return self.mLayer.currentLayer()

    def get_layercut (self):
        return self.mLayer_cut.currentLayer()

    def get_strm (self):
        if self.mLayer_srtm.currentLayer():
            return  self.mLayer_srtm.currentLayer().dataProvider()
        else: return False

    def get_featwells (self):
        return [feat for feat in self.mLayer.currentLayer().getFeatures()]

    def get_selfeatwells (self):
        return self.mLayer.currentLayer().selectedFeatures()

    def get_featcut (self):
        layer = self.mLayer_cut.currentLayer()
        if self.chBox_cutfeats.isChecked() :
            features = layer.selectedFeatures()
        else :
            features=[feature for feature in layer.getFeatures()]
        return features

        #return [feat for feat in self.mLayer_cut.currentLayer().getFeatures()]

    def get_fieldwells (self):
        return (
                self.mField_cutname.currentField(),
                self.mField_well.currentField(),
                self.mField_alt.currentField(),
                self.mField_file.currentField(),
                self.mField_gtr.currentField()
               )

    def get_dirlayer (self):
        return  os.path.dirname(self.mLayer.currentLayer().source())

    def getscale(self):
        return self.map_mScale.scale() / self.cut_mScale.scale()

    def get_mapcut_scale (self):
        return self.map_mScale.scale(), self.cut_mScale.scale()

    def get_izline (self):
        return (
                self.mLayer_izln.currentLayer(),
                self.mField_elev.currentField()
               )

    def get_rivers (self):
        if self.groupBox_rivers.isChecked():
            return (
                    self.mLayer_rivers.currentLayer(),
                    self.mField_rivers.currentField()
                   )
        else: return False

    def get_ages (self):
        if self.groupBox_ages.isChecked():
            return (
                    self.mLayer_ages.currentLayer(),
                    self.mField_ages.currentField()
                   )
        else: return False

    def get_lnplg (self):
        return self.data_lnplg

#-----------------------------------------------------------------------------
#       formCurveWells
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
#  Диалог зоны ЗСО
#  formZonezso
#-----------------------------------------------------------------------------
FORM_CLASS_4, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/zone_zso.ui'))

class formZonezso(QtWidgets.QDialog, FORM_CLASS_4):

    #checklist = []
    msgBox = QtWidgets.QMessageBox()
    # Описание диалогового окна создание полей радиусов
    # в аттрибутивной таблице слоя скважин
    msgAttr = QtWidgets.QMessageBox()
    msgAttr.setIcon(QMessageBox.Icon.Question)
    msgAttr.setText("В выбранном слое не обнаружено ни одного поля с\
                    атрибутами радиусов зон СО")
    msgAttr.setInformativeText("Добавить в атрибутивную таблицу\
                               необходимые поля?")
    msgAttr.setWindowTitle("Атрибуты")
    insButtn = msgAttr.addButton("Добавить", QMessageBox.ButtonRole.YesRole)
    canslButtn = msgAttr.addButton("Пропустить", QMessageBox.ButtonRole.NoRole)

    attr_existence = True

    LYR_CRS = 1
    PRJ_CRS = 2

    def __init__(self, parent=None):
        super(formZonezso, self).__init__(parent)
        self.setupUi(self)
        self.prj_crs = QgsProject.instance().crs()

        # Реакция на выбор слоя в mLayer
        self.layer_ComboBox.currentIndexChanged.connect(self.activ_layerbox)
        self.layer_ComboBox.setFilters(QgsMapLayerProxyModel.PointLayer)

        self.mFieldCB_wellname.setFilters(QgsFieldProxyModel.String|
                                          QgsFieldProxyModel.LongLong|
                                          QgsFieldProxyModel.Int)
        self.select_checkBox.setChecked(False)
        self.circle_checkBox.setChecked(False)

    # Описание реакции mLayer на активацию и выбор
    def activ_layerbox(self):
        layer = False
        #TODO
        layer = self.layer_ComboBox.currentLayer()
        if layer and layer.selectedFeatures() :
            self.select_checkBox.setEnabled(True)
        else:
            self.select_checkBox.setEnabled(False)
        # Определение crs выбранного слоя
        if layer :
            self.layer_crs = layer.crs()
            self.mFieldCB_wellname.setLayer(layer)

    # Перегрузка метода диалогового окна accept для
    # проверки заполненности всех полей формы
    def accept (self) :
        if self.checkzone() : self.done(QDialog.DialogCode.Accepted)

    # Подготовка и запуск формы диалога
    def run(self):
        self.exec()
        return self.result()

    # Проверка наличия полей с радиусами
    def checkzone (self) :
        layer = self.layer_ComboBox.currentLayer()
        fnm = layer.fields().names()

        self.checklist = [False, False, False, False]

        if not self.layer_crs.isGeographic() :
            self.checklist[3] = self.LYR_CRS
            msgTxt = f"Проекция слоя: {self.layer_crs.authid()} - \
{self.layer_crs.description()}"
        elif not self.prj_crs.isGeographic() :
            self.checklist[3] = self.PRJ_CRS
            msgTxt = f"Проекция проекта: {self.prj_crs.authid()} - \
{self.prj_crs.description()}"
        else:
            self.msgBox.critical(self, "Проверка проекции",
                                 "Нет данных о проекции.")
            return False

        if 'r1' in fnm : self.checklist[0] = True
        else: msgTxt += "\nОтсутствует поле первого пояса 'r1'."
        if (('r_n2' in fnm) and ('r_w2' in fnm) and
            ('r_s2' in fnm) and ('r_o2' in fnm)) :
            self.checklist[1] = True
        else: msgTxt += "\nОтсутствует поле первого пояса 'r_2'."
        if (('r_n3' in fnm) and ('r_w3' in fnm) and
            ('r_s3' in fnm) and ('r_o3' in fnm)) :
            self.checklist[2] = True
        else: msgTxt += "\nОтсутствует поле первого пояса 'r_3'."

        if True in self.checklist[0:2] :
            self.msgBox.information(self, "Проверка данных", msgTxt)
            return True
        else:
            #self.msgBox.critical(self, "Проверка данных",
            #                     "Отсутствуют поля радиусов")
            self.msgAttr.exec()
            if self.msgAttr.clickedButton() == self.insButtn:
                self.attr_existence = False
                return True
            elif self.msgAttr.clickedButton() == self.canslButtn:
                return False

    def getfeatures(self):
        layer = self.layer_ComboBox.currentLayer()
        if self.select_checkBox.isChecked() :
            features = layer.selectedFeatures()
        else :
            features=[feature for feature in layer.getFeatures()]
        return features

    def getazimut(self):
        if (self.azimut_spinBox.value() < 0):
            return self.azimut_spinBox.value()+270
        else:
            return self.azimut_spinBox.value()-90
    #TODO
    def getcrs(self):
        if self.checklist[3] == self.PRJ_CRS :
            return self.layer_crs, self.prj_crs
        else:
            return self.layer_crs, False

    def getnamefield (self):
        return self.mFieldCB_wellname.currentField()

    def getlayer(self):
        return self.layer_ComboBox.currentLayer()

    def r1type(self):
        return self.circle_checkBox.isChecked()
#-----------------------------------------------------------------------------
#       formZonezso
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Форма скрипта загрузки кадастровых участков в GeoJson
# formGeojsontoShape
#-----------------------------------------------------------------------------
FORM_CLASS_5, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/json_to_shape.ui'))


class formGeojsontoShape(QtWidgets.QDialog, FORM_CLASS_5):
    msgBox = QtWidgets.QMessageBox()

    def __init__(self, parent=None):
        super(formGeojsontoShape, self).__init__(parent)
        self.setupUi(self)

        self.cadastr_list_file.setFilter('Текстовый файл (*.txt);;\
                                          Любой файл (*)')

    # Подготовка и запуск формы диалога
    def run(self):
        self.exec()
        return self.result()

    # Перегрузка ok
    def accept(self):
        if not self.cadastr_list_file.lineEdit().text():
            self.msgBox.warning(self,
                                "Ошибка выполнения",
                                "Файла не существует"
                                )
        else: self.done(QDialog.DialogCode.Accepted)

    # Путь к файлу с номерами кадастровых участков
    def cadastr_path(self):
        return self.cadastr_list_file.lineEdit().text()
#-----------------------------------------------------------------------------
# formGeojsontoShape
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
#  Диалог буферов зон пластов пересечения
#  formBufferIntersectZone
#-----------------------------------------------------------------------------
FORM_CLASS_6, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/buffer_intersect.ui'))

class formBufferIntersectZone(QtWidgets.QDialog, FORM_CLASS_6):

    #checklist = []
    msgBox = QtWidgets.QMessageBox()
    # Описание диалогового окна создание полей радиусов
    # в аттрибутивной таблице слоя скважин
    LYR_CRS = 1
    PRJ_CRS = 2

    def __init__(self, parent=None):
        super(formBufferIntersectZone, self).__init__(parent)
        self.setupUi(self)
        self.prj_crs = QgsProject.instance().crs()

        # Реакция на выбор слоя в mLayer
        self.layer_ComboBox.currentIndexChanged.connect(self.activ_layerbox)
        self.layer_ComboBox.setFilters(QgsMapLayerProxyModel.PointLayer)

        self.radius_mField.setFilters(QgsFieldProxyModel.Numeric) # Double

        self.select_checkBox.setChecked(False)
        # doubleSpinBox точность подбора площади буфера
        self.decim_SpinBox.setDecimals(4)
        self.decim_SpinBox.setSuffix(' %')
        self.decim_SpinBox.setValue(0.001)
        self.decim_SpinBox.setMinimum(0.0001)
        self.decim_SpinBox.setSingleStep(0.001)

    # Описание реакции mLayer на активацию и выбор
    def activ_layerbox(self):
        layer = False
        layer = self.layer_ComboBox.currentLayer()
        if layer and layer.selectedFeatures() :
            self.select_checkBox.setEnabled(True)
        else:
            self.select_checkBox.setEnabled(False)
        # Определение crs выбранного слоя
        if layer :
            self.layer_crs = layer.crs()
            self.radius_mField.setLayer(layer)

    # Перегрузка метода диалогового окна accept для
    # проверки заполненности всех полей формы
    def accept (self) :
        if self.checkzone() : self.done(QDialog.DialogCode.Accepted)

    # Подготовка и запуск формы диалога
    def run(self):
        self.exec()
        return self.result()

    # Проверка наличия полей с радиусами
    def checkzone (self) :
        layer = self.layer_ComboBox.currentLayer()

        if not self.layer_crs.isGeographic() :
            self.current_crs = self.LYR_CRS
            msgTxt = f"Проекция слоя: {self.layer_crs.authid()} - \
{self.layer_crs.description()}"
            self.msgBox.information(self, 'Проверка проекции', msgTxt)
            #return True
        elif not self.prj_crs.isGeographic() :
            self.current_crs = self.PRJ_CRS
            msgTxt = f"Проекция проекта: {self.prj_crs.authid()} - \
{self.prj_crs.description()}"
            self.msgBox.information(self, "Проверка проекции", msgTxt)
            #return True
        else:
            self.msgBox.critical(self, "Проверка проекции",
                                 "Нет данных о проекции.")
            return False
        if self.radius_mField.currentField():
            return True
        else:
            self.msgBox.critical(self, "Проверка данных",
                            "Не выбрано поле радиусов пластов пересечения.")
            return False

    def getfeatures(self):
        layer = self.layer_ComboBox.currentLayer()
        if self.select_checkBox.isChecked() :
            features = layer.selectedFeatures()
        else :
            features=[feature for feature in layer.getFeatures()]
        return features

    def getnamefield (self):
        return self.radius_mField.currentField()

    def getcrs(self):
        if self.current_crs == self.PRJ_CRS :
            return self.layer_crs, self.prj_crs
        else:
            return self.layer_crs, False

    def getDecimal (self):
        return self.decim_SpinBox.value()
#-----------------------------------------------------------------------------
#       formBufferIntersectZone
#-----------------------------------------------------------------------------
